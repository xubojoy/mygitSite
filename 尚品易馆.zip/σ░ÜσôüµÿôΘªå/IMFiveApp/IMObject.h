//
//  IMObject.h
//  IMFiveApp
//
//  Created by chen on 14-8-29.
//  Copyright (c) 2014年 chen. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface IMObject : NSObject

@property (nonatomic, assign) int nTheme;

@end
