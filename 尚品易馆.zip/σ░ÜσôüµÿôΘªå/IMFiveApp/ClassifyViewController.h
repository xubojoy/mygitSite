//
//  ContactsViewController.h
//  IMApp
//
//  Created by chen on 14/7/20.
//  Copyright (c) 2014年 chen. All rights reserved.
//

@interface ClassifyViewController : QHBasicViewController<UIWebViewDelegate>
@property (strong, nonatomic) UIWebView *webView;
@property (nonatomic, strong) NetProcessor *netProcessor;
@property (strong, nonatomic) UIActivityIndicatorView *activityIndicator;
@end
