//
//  LeftViewController.h
//  WYApp
//
//  Created by chen on 14-7-17.
//  Copyright (c) 2014年 chen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeftViewController : QHBasicViewController

@property (nonatomic, retain) UIView *contentView;
@property (strong,nonatomic) UITableView* myTableView;
@end
