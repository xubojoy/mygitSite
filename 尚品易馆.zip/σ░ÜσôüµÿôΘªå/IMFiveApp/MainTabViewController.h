//
//  HomePageViewController.h
//  IMApp
//
//  Created by chen on 14/7/20.
//  Copyright (c) 2014年 chen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainTabViewController : QHBasicViewController<UIWebViewDelegate>
@property (strong, nonatomic) UIWebView *webView;

@property (strong, nonatomic) UIActivityIndicatorView *activityIndicator;
+ (MainTabViewController *)getMain;
@end
