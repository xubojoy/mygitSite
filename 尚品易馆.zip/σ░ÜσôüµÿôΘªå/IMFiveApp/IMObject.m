//
//  IMObject.m
//  IMFiveApp
//
//  Created by chen on 14-8-29.
//  Copyright (c) 2014年 chen. All rights reserved.
//

#import "IMObject.h"

@implementation IMObject

- (id)init
{
    self = [super init];
    
    _nTheme = 0;
    
    return self;
}

@end
