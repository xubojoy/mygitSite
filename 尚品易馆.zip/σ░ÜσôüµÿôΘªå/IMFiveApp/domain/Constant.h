//
//  Constant.h
//  IMFiveApp
//
//  Created by 王圆圆 on 14-10-27.
//  Copyright (c) 2014年 chen. All rights reserved.
//

#ifndef IMFiveApp_Constant_h
#define IMFiveApp_Constant_h

#define IOS6 [[UIDevice currentDevice].systemVersion floatValue] <7
#define IOS7 [[UIDevice currentDevice].systemVersion floatValue] >=7
#define IOS8 [[UIDevice currentDevice].systemVersion floatValue] >=8

#endif
